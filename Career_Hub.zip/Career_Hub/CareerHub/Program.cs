﻿using CareerHub.App;

namespace CareerHub
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CareerHubManagement careerHubManagement = new CareerHubManagement();
            careerHubManagement.App();
        }
    }
}